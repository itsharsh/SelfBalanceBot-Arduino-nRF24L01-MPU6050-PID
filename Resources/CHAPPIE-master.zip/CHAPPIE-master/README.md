# CHAPPIE
A Self Balancing Robot

#<a href="https://www.youtube.com/watch?v=6rJHeusWy0k">Youtube</a> video
[![ScreenShot](http://img.youtube.com/vi/6rJHeusWy0k/0.jpg)](https://www.youtube.com/watch?v=6rJHeusWy0k)


For More Information,code,tutorial,visit-
<a href="http://electronics2work.com/SelfBalancing.html">Electronics2Work</a>

