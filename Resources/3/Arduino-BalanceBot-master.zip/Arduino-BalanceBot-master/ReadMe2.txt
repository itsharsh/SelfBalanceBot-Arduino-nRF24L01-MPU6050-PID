* This code contained in this project
* was written to work with a car whose components are arranged as described in:  
* BalanceBotWiringDiagram.pdf                                                              
* and a L298N Break-Out Board configured as shown in:
* L298NdualHbridge.JPG